package com.nice.launcher

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

enum class Screen { Home, Drawer, Settings }

class MainActivity : ComponentActivity() {
    private var homeTick by mutableIntStateOf(0)
    private var resumeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val st = LauncherSettings(this)
        setContent { LauncherApp(st, homeTick, resumeTick) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        homeTick++
    }

    override fun onResume() {
        super.onResume()
        resumeTick++
    }
}

fun Modifier.glass(alpha: Float, r: Dp = 24.dp): Modifier {
    val shape = RoundedCornerShape(r)
    return this.clip(shape).background(Color.White.copy(alpha)).border(1.dp, Color.White.copy(0.22f), shape)
}

fun launchPkg(ctx: Context, pkg: String) {
    ctx.packageManager.getLaunchIntentForPackage(pkg)?.let {
        it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(it)
    }
}

fun findApp(apps: List<AppItem>, name: String): AppItem? =
    apps.firstOrNull { it.label.equals(name, true) }
        ?: apps.firstOrNull { it.label.contains(name, true) }
        ?: apps.firstOrNull { name.contains(it.label, true) }

/** Runs one action returned by the AI. Returns an error note, or null on success. */
fun exec(ctx: Context, a: JSONObject, apps: List<AppItem>): String? = try {
    fun go(i: Intent) { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    when (a.optString("type")) {
        "open_app" -> {
            val n = a.optString("name")
            val app = findApp(apps, n)
            if (app == null) "Couldn't find an app called \"$n\"" else { launchPkg(ctx, app.pkg); null }
        }
        "open_url" -> { go(Intent(Intent.ACTION_VIEW, Uri.parse(a.optString("url")))); null }
        "web_search" -> {
            go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.optString("query")))))
            null
        }
        "set_timer" -> {
            go(Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, a.optInt("seconds", 60))
                .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label"))
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            null
        }
        "set_alarm" -> {
            go(Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour", 7))
                .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute", 0))
                .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label"))
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            null
        }
        "call" -> { go(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + a.optString("number")))); null }
        else -> "Unknown action: ${a.optString("type")}"
    }
} catch (e: Exception) {
    "Action failed: ${e.message}"
}

@Composable
fun LauncherApp(st: LauncherSettings, homeTick: Int, resumeTick: Int) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf(emptyList<AppItem>()) }
    LaunchedEffect(resumeTick) { apps = withContext(Dispatchers.Default) { loadApps(ctx) } }
    var screen by remember { mutableStateOf(Screen.Home) }
    var showAi by remember { mutableStateOf(false) }
    LaunchedEffect(homeTick) { screen = Screen.Home; showAi = false }
    BackHandler { if (showAi) showAi = false else screen = Screen.Home }

    val accent = Accents[st.accent.coerceIn(0, Accents.lastIndex)]
    MaterialTheme(colorScheme = darkColorScheme(primary = accent)) {
        CompositionLocalProvider(LocalContentColor provides Color.White) {
            Box(Modifier.fillMaxSize()) {
                Home(st, apps, accent,
                    onDrawer = { screen = Screen.Drawer },
                    onSettings = { screen = Screen.Settings },
                    onAi = { showAi = true },
                    onOpen = { launchPkg(ctx, it) })
                val slide = slideInVertically { it } + fadeIn()
                val out = slideOutVertically { it } + fadeOut()
                AnimatedVisibility(screen == Screen.Drawer, enter = slide, exit = out) {
                    Drawer(st, apps, onOpen = { launchPkg(ctx, it); screen = Screen.Home })
                }
                AnimatedVisibility(screen == Screen.Settings, enter = slide, exit = out) {
                    SettingsScreen(st, accent) { screen = Screen.Home }
                }
                AnimatedVisibility(showAi, enter = slide, exit = out) {
                    AiSheet(st, accent, onClose = { showAi = false }, exec = { exec(ctx, it, apps) })
                }
            }
        }
    }
}

@Composable
fun Home(
    st: LauncherSettings, apps: List<AppItem>, accent: Color,
    onDrawer: () -> Unit, onSettings: () -> Unit, onAi: () -> Unit, onOpen: (String) -> Unit
) {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) { now = LocalDateTime.now(); delay(1000L * (60 - now.second)) }
    }
    val t by rememberInfiniteTransition(label = "aurora").animateFloat(
        0f, 1f, infiniteRepeatable(tween(12000, easing = LinearEasing), RepeatMode.Reverse), label = "t"
    )
    val dockApps = st.dock.mapNotNull { p -> apps.find { it.pkg == p } }

    Box(
        Modifier.fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(accent.copy(0.40f), Color.Transparent, Color.Black.copy(0.60f)),
                    start = Offset(0f, 0f), end = Offset(900f * t + 500f, 2400f)
                )
            )
            .pointerInput(Unit) { detectVerticalDragGestures { _, dy -> if (dy < -20f) onDrawer() } }
            .pointerInput(Unit) { detectTapGestures(onLongPress = { onSettings() }) }
    ) {
        Column(
            Modifier.fillMaxSize().systemBarsPadding().padding(24.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Spacer(Modifier.height(48.dp))
            Text(now.format(DateTimeFormatter.ofPattern("HH:mm")), fontSize = 84.sp, fontWeight = FontWeight.Thin)
            Text(now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM")), fontSize = 18.sp, color = Color.White.copy(0.8f))
            Spacer(Modifier.weight(1f))
            Row(
                Modifier.fillMaxWidth().glass(st.glass + 0.05f, 28.dp).clickable { onAi() }.padding(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("✦", fontSize = 20.sp, color = accent)
                Spacer(Modifier.width(12.dp))
                Text("Ask AI to do something…", color = Color.White.copy(0.75f))
            }
            Spacer(Modifier.height(16.dp))
            Row(
                Modifier.fillMaxWidth().glass(st.glass, 32.dp).padding(vertical = 14.dp).heightIn(min = 54.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (dockApps.isEmpty()) {
                    Text("Long-press an app in the drawer to pin it", fontSize = 13.sp, color = Color.White.copy(0.6f))
                }
                dockApps.forEach { a ->
                    Image(a.icon, a.label, Modifier.size(54.dp).clip(CircleShape).clickable { onOpen(a.pkg) })
                }
            }
            Spacer(Modifier.height(10.dp))
            Text("⌃ swipe up for apps · long-press for settings", fontSize = 11.sp,
                color = Color.White.copy(0.45f), modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Drawer(st: LauncherSettings, apps: List<AppItem>, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    val list = remember(apps, q) { if (q.isBlank()) apps else apps.filter { it.label.contains(q.trim(), true) } }
    Column(Modifier.fillMaxSize().background(Color(0xE60B0B12)).systemBarsPadding().padding(horizontal = 16.dp)) {
        OutlinedTextField(
            q, { q = it }, singleLine = true,
            placeholder = { Text("Search apps") },
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { list.firstOrNull()?.let { onOpen(it.pkg) } })
        )
        LazyVerticalGrid(GridCells.Fixed(st.columns.coerceIn(3, 6)), contentPadding = PaddingValues(vertical = 16.dp)) {
            items(list, key = { it.pkg }) { app ->
                var menu by remember { mutableStateOf(false) }
                val pinned = app.pkg in st.dock
                Box {
                    Column(
                        Modifier.clip(RoundedCornerShape(16.dp))
                            .combinedClickable(onClick = { onOpen(app.pkg) }, onLongClick = { menu = true })
                            .padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(app.icon, app.label, Modifier.size(54.dp))
                        Spacer(Modifier.height(4.dp))
                        Text(app.label, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    DropdownMenu(menu, { menu = false }) {
                        DropdownMenuItem(
                            text = { Text(if (pinned) "Unpin from dock" else "Pin to dock") },
                            onClick = {
                                menu = false
                                st.dock = if (pinned) st.dock - app.pkg else if (st.dock.size < 5) st.dock + app.pkg else st.dock
                                st.save()
                            })
                        DropdownMenuItem(text = { Text("App info") }, onClick = {
                            menu = false
                            ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        })
                        DropdownMenuItem(text = { Text("Uninstall") }, onClick = {
                            menu = false
                            ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        })
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(st: LauncherSettings, accent: Color, onClose: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Color(0xF2101018)).systemBarsPadding()
            .verticalScroll(rememberScrollState()).padding(20.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Settings", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("✕", fontSize = 24.sp, modifier = Modifier.clickable { onClose() }.padding(8.dp))
        }
        Spacer(Modifier.height(20.dp))
        Text("Accent colour", color = accent, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Accents.forEachIndexed { i, c ->
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(c)
                        .border(3.dp, if (i == st.accent) Color.White else Color.Transparent, CircleShape)
                        .clickable { st.accent = i; st.save() }
                )
            }
        }
        Spacer(Modifier.height(24.dp))
        Text("Glass opacity", color = accent, fontWeight = FontWeight.SemiBold)
        Slider(st.glass, { st.glass = it; st.save() }, valueRange = 0.05f..0.5f)
        Text("Drawer columns: ${st.columns}", color = accent, fontWeight = FontWeight.SemiBold)
        Slider(st.columns.toFloat(), { st.columns = it.roundToInt(); st.save() }, valueRange = 3f..6f, steps = 2)
        Spacer(Modifier.height(24.dp))
        Text("AI assistant (OpenAI)", color = accent, fontWeight = FontWeight.SemiBold)
        Text(
            "Paste an API key from platform.openai.com. This is separate from a ChatGPT subscription and billed per use. The key is stored only on this phone.",
            fontSize = 13.sp, color = Color.White.copy(0.65f), modifier = Modifier.padding(vertical = 8.dp)
        )
        OutlinedTextField(
            st.apiKey, { st.apiKey = it; st.save() }, singleLine = true,
            label = { Text("API key") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            st.model, { st.model = it; st.save() }, singleLine = true,
            label = { Text("Model") }, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(30.dp))
    }
}

class Msg(val fromUser: Boolean, val text: String)

@Composable
fun AiSheet(st: LauncherSettings, accent: Color, onClose: () -> Unit, exec: (JSONObject) -> String?) {
    val msgs = remember {
        mutableStateListOf(Msg(false, "Hey! Tell me what to do, e.g. “open Spotify”, “set a 10 minute timer” or “search pizza near me”."))
    }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    LaunchedEffect(msgs.size, busy) { listState.animateScrollToItem(msgs.size) }

    fun send() {
        val text = input.trim()
        if (text.isEmpty() || busy) return
        input = ""
        msgs.add(Msg(true, text))
        if (st.apiKey.isBlank()) {
            msgs.add(Msg(false, "Add your OpenAI API key first: close this, long-press the home screen, open Settings."))
            return
        }
        busy = true
        scope.launch {
            try {
                val hist = msgs.drop(1).takeLast(12).map { (if (it.fromUser) "user" else "assistant") to it.text }
                val r = Ai.ask(st.apiKey.trim(), st.model.trim(), hist)
                val notes = mutableListOf<String>()
                r.optJSONArray("actions")?.let { arr ->
                    for (i in 0 until arr.length()) exec(arr.getJSONObject(i))?.let { notes.add("⚠ $it") }
                }
                msgs.add(Msg(false, (listOf(r.optString("say")) + notes).filter { it.isNotBlank() }.joinToString("\n")))
            } catch (e: Exception) {
                msgs.add(Msg(false, "⚠ ${e.message}"))
            }
            busy = false
        }
    }

    Column(Modifier.fillMaxSize().background(Color(0xF2090910)).systemBarsPadding().imePadding().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("✦ Assistant", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = accent, modifier = Modifier.weight(1f))
            Text("✕", fontSize = 24.sp, modifier = Modifier.clickable { onClose() }.padding(8.dp))
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(msgs.size) { i ->
                val m = msgs[i]
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
                    Text(
                        m.text,
                        Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(18.dp))
                            .background(if (m.fromUser) accent.copy(0.85f) else Color.White.copy(0.10f)).padding(12.dp)
                    )
                }
            }
            if (busy) item { Text("…", color = Color.White.copy(0.6f), modifier = Modifier.padding(8.dp)) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                input, { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Tell me what to do") }, shape = RoundedCornerShape(28.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send() })
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { send() }, enabled = !busy) { Text("➤") }
        }
    }
}
