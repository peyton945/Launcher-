package com.nice.launcher

import android.content.Context
import android.content.Intent
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

val Accents = listOf(
    Color(0xFF7C4DFF), Color(0xFF00E5FF), Color(0xFFFF4081),
    Color(0xFF69F0AE), Color(0xFFFFAB40), Color(0xFF448AFF)
)

class LauncherSettings(ctx: Context) {
    private val sp = ctx.getSharedPreferences("nice_launcher", Context.MODE_PRIVATE)
    var apiKey by mutableStateOf(sp.getString("key", "") ?: "")
    var model by mutableStateOf(sp.getString("model", "gpt-4o-mini") ?: "gpt-4o-mini")
    var accent by mutableStateOf(sp.getInt("accent", 0))
    var glass by mutableStateOf(sp.getFloat("glass", 0.18f))
    var columns by mutableStateOf(sp.getInt("cols", 4))
    var dock by mutableStateOf((sp.getString("dock", "") ?: "").split(",").filter { it.isNotBlank() })

    fun save() {
        sp.edit()
            .putString("key", apiKey).putString("model", model)
            .putInt("accent", accent).putFloat("glass", glass)
            .putInt("cols", columns).putString("dock", dock.joinToString(","))
            .apply()
    }
}

class AppItem(val label: String, val pkg: String, val icon: ImageBitmap)

private val iconCache = HashMap<String, ImageBitmap>()

fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(q, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .distinctBy { it.activityInfo.packageName }
        .map { ri ->
            val p = ri.activityInfo.packageName
            AppItem(
                ri.loadLabel(pm).toString(), p,
                iconCache.getOrPut(p) { ri.loadIcon(pm).toBitmap(128, 128).asImageBitmap() }
            )
        }
        .sortedBy { it.label.lowercase() }
}

object Ai {
    private const val SYSTEM = """You are the assistant built into an Android launcher. The user gives you commands. 
Respond ONLY with a JSON object: {"say": "short friendly reply", "actions": [ ... ]}.
Available action objects:
{"type":"open_app","name":"App name"}
{"type":"open_url","url":"https://..."}
{"type":"web_search","query":"..."}
{"type":"set_timer","seconds":600,"label":"..."}
{"type":"set_alarm","hour":7,"minute":30,"label":"..."}
{"type":"call","number":"+123456789"}
Use an empty actions array for plain conversation. Only include actions the user asked for."""

    suspend fun ask(key: String, model: String, history: List<Pair<String, String>>): JSONObject =
        withContext(Dispatchers.IO) {
            val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", SYSTEM))
            history.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
            val body = JSONObject()
                .put("model", model)
                .put("response_format", JSONObject().put("type", "json_object"))
                .put("messages", msgs)
            val c = URL("https://api.openai.com/v1/chat/completions").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.setRequestProperty("Authorization", "Bearer $key")
            c.setRequestProperty("Content-Type", "application/json")
            c.doOutput = true
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = try { JSONObject(text).getJSONObject("error").getString("message") } catch (e: Exception) { text.take(200) }
                throw IllegalStateException("OpenAI error $code: $msg")
            }
            val content = JSONObject(text).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
            JSONObject(content)
        }
}
