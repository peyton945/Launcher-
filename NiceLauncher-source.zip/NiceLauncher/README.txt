Nice Launcher: open this folder in Android Studio (Koala or newer), let Gradle sync,
press Run, then press Home and pick "Nice Launcher" -> Always.
