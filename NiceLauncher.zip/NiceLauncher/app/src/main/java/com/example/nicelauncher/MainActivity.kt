package com.example.nicelauncher

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

data class AppInfo(val label: String, val pkg: String, val icon: ImageBitmap)

class MainActivity : ComponentActivity() {

    private var apps by mutableStateOf<List<AppInfo>>(emptyList())
    private var pinned by mutableStateOf<List<String>>(emptyList())
    private var drawerOpen by mutableStateOf(false)

    private val prefs by lazy { getSharedPreferences("launcher", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        pinned = prefs.getString("pinned", "")!!.split(",").filter { it.isNotBlank() }

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                LauncherScreen(
                    apps = apps,
                    pinned = pinned,
                    drawerOpen = drawerOpen,
                    onDrawer = { drawerOpen = it },
                    onLaunch = ::launch,
                    onTogglePin = ::togglePin,
                    onInfo = ::openInfo,
                    onUninstall = ::uninstall,
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        loadApps()
    }

    // Pressing Home while already on the launcher closes the drawer.
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) drawerOpen = false
    }

    private fun loadApps() {
        lifecycleScope.launch {
            val list = withContext(Dispatchers.Default) {
                val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                packageManager.queryIntentActivities(query, 0)
                    .filter { it.activityInfo.packageName != packageName }
                    .map {
                        AppInfo(
                            label = it.loadLabel(packageManager).toString(),
                            pkg = it.activityInfo.packageName,
                            icon = it.loadIcon(packageManager).toBitmap(144, 144).asImageBitmap(),
                        )
                    }
                    .distinctBy { it.pkg }
                    .sortedBy { it.label.lowercase() }
            }
            apps = list
            // Drop pinned apps that were uninstalled.
            val valid = pinned.filter { p -> list.any { it.pkg == p } }
            if (valid != pinned) savePinned(valid)
        }
    }

    private fun savePinned(list: List<String>) {
        pinned = list
        prefs.edit().putString("pinned", list.joinToString(",")).apply()
    }

    private fun togglePin(pkg: String) {
        if (pkg in pinned) savePinned(pinned - pkg)
        else if (pinned.size < 5) savePinned(pinned + pkg)
    }

    private fun launch(pkg: String) {
        packageManager.getLaunchIntentForPackage(pkg)?.let {
            drawerOpen = false
            startActivity(it)
        }
    }

    private fun openInfo(pkg: String) {
        startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
        )
    }

    private fun uninstall(pkg: String) {
        startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
    }
}

@Composable
fun LauncherScreen(
    apps: List<AppInfo>,
    pinned: List<String>,
    drawerOpen: Boolean,
    onDrawer: (Boolean) -> Unit,
    onLaunch: (String) -> Unit,
    onTogglePin: (String) -> Unit,
    onInfo: (String) -> Unit,
    onUninstall: (String) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    LaunchedEffect(drawerOpen) { if (!drawerOpen) query = "" }
    BackHandler(enabled = drawerOpen) { onDrawer(false) }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -120f) onDrawer(true) },
                ) { _, dy -> total += dy }
            }
    ) {
        HomePage(apps, pinned, onLaunch, onTogglePin, onInfo, onUninstall, onOpenDrawer = { onDrawer(true) })

        AnimatedVisibility(
            visible = drawerOpen,
            enter = slideInVertically { it / 3 } + fadeIn(),
            exit = slideOutVertically { it / 3 } + fadeOut(),
        ) {
            Drawer(
                apps = apps,
                pinned = pinned,
                query = query,
                onQuery = { query = it },
                onLaunch = onLaunch,
                onTogglePin = onTogglePin,
                onInfo = onInfo,
                onUninstall = onUninstall,
                onClose = { onDrawer(false) },
            )
        }
    }
}

@Composable
fun HomePage(
    apps: List<AppInfo>,
    pinned: List<String>,
    onLaunch: (String) -> Unit,
    onTogglePin: (String) -> Unit,
    onInfo: (String) -> Unit,
    onUninstall: (String) -> Unit,
    onOpenDrawer: () -> Unit,
) {
    val now by produceState(LocalDateTime.now()) {
        while (true) { value = LocalDateTime.now(); delay(10_000) }
    }
    val time = now.format(DateTimeFormatter.ofPattern("HH:mm"))
    val date = now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault()))

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.25f))
            .systemBarsPadding()
            .padding(horizontal = 24.dp),
    ) {
        Spacer(Modifier.height(72.dp))
        Text(time, color = Color.White, fontSize = 72.sp, fontWeight = FontWeight.Light)
        Text(date, color = Color.White.copy(alpha = 0.8f), fontSize = 18.sp)

        Spacer(Modifier.weight(1f))

        Text(
            "Swipe up for apps",
            color = Color.White.copy(alpha = 0.5f),
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
        )

        // Dock
        Row(
            Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
                .clip(RoundedCornerShape(32.dp))
                .background(Color.White.copy(alpha = 0.15f))
                .padding(vertical = 12.dp, horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            val dockApps = pinned.mapNotNull { p -> apps.find { it.pkg == p } }
            if (dockApps.isEmpty()) {
                Text(
                    "Long-press an app to pin it here",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 14.sp,
                    modifier = Modifier.padding(16.dp),
                )
            }
            dockApps.forEach { app ->
                AppItem(app, true, false, onLaunch, onTogglePin, onInfo, onUninstall)
            }
        }
    }
}

@Composable
fun Drawer(
    apps: List<AppInfo>,
    pinned: List<String>,
    query: String,
    onQuery: (String) -> Unit,
    onLaunch: (String) -> Unit,
    onTogglePin: (String) -> Unit,
    onInfo: (String) -> Unit,
    onUninstall: (String) -> Unit,
    onClose: () -> Unit,
) {
    val filtered = remember(apps, query) {
        if (query.isBlank()) apps else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xE6101014))
            .systemBarsPadding()
            .imePadding()
            .padding(horizontal = 12.dp),
    ) {
        Box(
            Modifier
                .padding(top = 10.dp, bottom = 8.dp)
                .align(Alignment.CenterHorizontally)
                .size(width = 40.dp, height = 4.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(Color.White.copy(alpha = 0.3f))
                .pointerInput(Unit) {
                    detectVerticalDragGestures { _, dy -> if (dy > 8f) onClose() }
                }
        )

        TextField(
            value = query,
            onValueChange = onQuery,
            placeholder = { Text("Search apps") },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            colors = TextFieldDefaults.colors(
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                focusedContainerColor = Color.White.copy(alpha = 0.12f),
                unfocusedContainerColor = Color.White.copy(alpha = 0.12f),
            ),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = {
                filtered.firstOrNull()?.let { onLaunch(it.pkg) }
            }),
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp),
        ) {
            items(filtered, key = { it.pkg }) { app ->
                AppItem(app, app.pkg in pinned, true, onLaunch, onTogglePin, onInfo, onUninstall)
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppItem(
    app: AppInfo,
    isPinned: Boolean,
    showLabel: Boolean,
    onLaunch: (String) -> Unit,
    onTogglePin: (String) -> Unit,
    onInfo: (String) -> Unit,
    onUninstall: (String) -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    Box {
        Column(
            Modifier
                .clip(RoundedCornerShape(16.dp))
                .combinedClickable(
                    onClick = { onLaunch(app.pkg) },
                    onLongClick = { menu = true },
                )
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Image(app.icon, contentDescription = app.label, modifier = Modifier.size(56.dp))
            if (showLabel) {
                Spacer(Modifier.height(4.dp))
                Text(
                    app.label,
                    color = Color.White,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.widthIn(max = 72.dp),
                )
            }
        }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(
                text = { Text(if (isPinned) "Unpin from dock" else "Pin to dock") },
                onClick = { menu = false; onTogglePin(app.pkg) },
            )
            DropdownMenuItem(text = { Text("App info") }, onClick = { menu = false; onInfo(app.pkg) })
            DropdownMenuItem(text = { Text("Uninstall") }, onClick = { menu = false; onUninstall(app.pkg) })
        }
    }
}
