package com.example.nicelauncher

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

data class AppInfo(val label: String, val pkg: String, val icon: ImageBitmap)
data class MenuItem(val label: String, val run: () -> Unit)

class Actions(
    val launch: (String) -> Unit,
    val info: (String) -> Unit,
    val uninstall: (String) -> Unit,
    val lock: () -> Unit,
    val notifications: () -> Unit,
    val accessibility: () -> Unit,
)

val AccentColors = listOf(
    Color(0xFF7C9CFF), Color(0xFFFF7C9C), Color(0xFF7CFFB2),
    Color(0xFFFFC857), Color(0xFFB57CFF), Color(0xFFFFFFFF),
)

class LauncherPrefs(private val sp: SharedPreferences) {
    var iconSize by mutableStateOf(sp.getInt("iconSize", 56))
    var accent by mutableStateOf(sp.getInt("accent", 0))
    var labels by mutableStateOf(sp.getBoolean("labels", true))
    var h24 by mutableStateOf(sp.getBoolean("h24", true))
    var fahrenheit by mutableStateOf(sp.getBoolean("f", false))
    var dock by mutableStateOf(sp.getString("pinned", "")!!.split(",").filter { it.isNotBlank() })
    var pages by mutableStateOf(
        List(2) { i -> sp.getString("page$i", "")!!.split(",").filter { it.isNotBlank() } }
    )

    fun save() {
        val e = sp.edit()
        e.putInt("iconSize", iconSize)
        e.putInt("accent", accent)
        e.putBoolean("labels", labels)
        e.putBoolean("h24", h24)
        e.putBoolean("f", fahrenheit)
        e.putString("pinned", dock.joinToString(","))
        pages.forEachIndexed { i, p -> e.putString("page$i", p.joinToString(",")) }
        e.apply()
    }
}

class MainActivity : ComponentActivity() {

    private var apps by mutableStateOf<List<AppInfo>>(emptyList())
    private var drawerOpen by mutableStateOf(false)
    private lateinit var prefs: LauncherPrefs

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        prefs = LauncherPrefs(getSharedPreferences("launcher", Context.MODE_PRIVATE))
        val actions = Actions(
            launch = ::launch,
            info = ::openInfo,
            uninstall = ::uninstall,
            lock = ::lockScreen,
            notifications = ::openNotifications,
            accessibility = ::openAccessibility,
        )
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                LauncherScreen(apps, prefs, drawerOpen, { drawerOpen = it }, actions)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        loadApps()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) drawerOpen = false
    }

    private fun loadApps() {
        lifecycleScope.launch {
            val list = withContext(Dispatchers.Default) {
                val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                packageManager.queryIntentActivities(query, 0)
                    .filter { it.activityInfo.packageName != packageName }
                    .map {
                        AppInfo(
                            label = it.loadLabel(packageManager).toString(),
                            pkg = it.activityInfo.packageName,
                            icon = it.loadIcon(packageManager).toBitmap(144, 144).asImageBitmap(),
                        )
                    }
                    .distinctBy { it.pkg }
                    .sortedBy { it.label.lowercase() }
            }
            apps = list
            if (list.isNotEmpty()) {
                val valid = list.map { it.pkg }.toSet()
                prefs.dock = prefs.dock.filter { it in valid }
                prefs.pages = prefs.pages.map { p -> p.filter { it in valid } }
                prefs.save()
            }
        }
    }

    private fun launch(pkg: String) {
        packageManager.getLaunchIntentForPackage(pkg)?.let {
            drawerOpen = false
            startActivity(it)
        }
    }

    private fun openInfo(pkg: String) {
        startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
        )
    }

    private fun uninstall(pkg: String) {
        startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
    }

    private fun lockScreen() {
        val s = LockService.instance
        if (s != null) {
            s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
        } else {
            Toast.makeText(this, "Turn on Nice Launcher in Accessibility settings", Toast.LENGTH_LONG).show()
            openAccessibility()
        }
    }

    private fun openNotifications() {
        LockService.instance?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
    }

    private fun openAccessibility() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }
}

@Composable
fun LauncherScreen(
    apps: List<AppInfo>,
    prefs: LauncherPrefs,
    drawerOpen: Boolean,
    onDrawer: (Boolean) -> Unit,
    act: Actions,
) {
    var query by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    LaunchedEffect(drawerOpen) { if (!drawerOpen) query = "" }
    BackHandler(enabled = drawerOpen) { onDrawer(false) }
    val accent = AccentColors[prefs.accent.coerceIn(0, AccentColors.lastIndex)]

    fun setPage(i: Int, f: (List<String>) -> List<String>) {
        prefs.pages = prefs.pages.mapIndexed { idx, p -> if (idx == i) f(p) else p }
        prefs.save()
    }

    // page == null: drawer, page == -1: dock, page >= 0: an app page
    fun actionsFor(app: AppInfo, page: Int?): List<MenuItem> {
        val list = mutableListOf<MenuItem>()
        if (page != null && page >= 0) {
            list += MenuItem("Remove from this page") { setPage(page) { p -> p - app.pkg } }
        }
        if (page == null) {
            for (i in prefs.pages.indices) {
                list += MenuItem("Add to page ${i + 2}") {
                    setPage(i) { p -> if (app.pkg in p) p else p + app.pkg }
                }
            }
        }
        val pinned = app.pkg in prefs.dock
        list += MenuItem(if (pinned) "Unpin from dock" else "Pin to dock") {
            prefs.dock = when {
                pinned -> prefs.dock - app.pkg
                prefs.dock.size < 5 -> prefs.dock + app.pkg
                else -> prefs.dock
            }
            prefs.save()
        }
        list += MenuItem("App info") { act.info(app.pkg) }
        list += MenuItem("Uninstall") { act.uninstall(app.pkg) }
        return list
    }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = {
                        if (total < -120f) onDrawer(true)
                        else if (total > 120f) act.notifications()
                    },
                ) { _, dy -> total += dy }
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onDoubleTap = { act.lock() },
                    onLongPress = { showSettings = true },
                )
            }
    ) {
        HomePage(apps, prefs, accent, act, ::actionsFor)

        AnimatedVisibility(
            visible = drawerOpen,
            enter = slideInVertically { it / 3 } + fadeIn(),
            exit = slideOutVertically { it / 3 } + fadeOut(),
        ) {
            Drawer(
                apps = apps,
                prefs = prefs,
                query = query,
                onQuery = { query = it },
                onLaunch = act.launch,
                actionsFor = ::actionsFor,
                onClose = { onDrawer(false) },
            )
        }

        if (showSettings) {
            SettingsDialog(prefs, act.accessibility) { showSettings = false }
        }
    }
}

@Composable
fun HomePage(
    apps: List<AppInfo>,
    prefs: LauncherPrefs,
    accent: Color,
    act: Actions,
    actionsFor: (AppInfo, Int?) -> List<MenuItem>,
) {
    val pageCount = 1 + prefs.pages.size
    val pagerState = rememberPagerState(pageCount = { pageCount })

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.25f))
            .systemBarsPadding(),
    ) {
        HorizontalPager(state = pagerState, modifier = Modifier.weight(1f).fillMaxWidth()) { page ->
            if (page == 0) {
                WidgetsPage(prefs, accent)
            } else {
                val idx = page - 1
                val list = prefs.pages[idx].mapNotNull { p -> apps.find { it.pkg == p } }
                if (list.isEmpty()) {
                    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                        Text(
                            "Empty page\nLong-press an app in the drawer and choose Add to page ${page + 1}",
                            color = Color.White.copy(alpha = 0.6f),
                            textAlign = TextAlign.Center,
                        )
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(4),
                        contentPadding = PaddingValues(top = 24.dp, start = 12.dp, end = 12.dp),
                    ) {
                        items(list, key = { it.pkg }) { app ->
                            AppItem(
                                app, prefs.iconSize, prefs.labels,
                                { act.launch(app.pkg) }, actionsFor(app, idx),
                                Modifier.fillMaxWidth(),
                            )
                        }
                    }
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            repeat(pageCount) { i ->
                val sel = pagerState.currentPage == i
                Box(
                    Modifier
                        .padding(4.dp)
                        .size(if (sel) 8.dp else 6.dp)
                        .clip(CircleShape)
                        .background(if (sel) accent else Color.White.copy(alpha = 0.4f))
                )
            }
        }

        Text(
            "Swipe up for apps",
            color = Color.White.copy(alpha = 0.5f),
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        )

        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 24.dp, end = 24.dp, bottom = 16.dp)
                .clip(RoundedCornerShape(32.dp))
                .background(accent.copy(alpha = 0.18f))
                .padding(vertical = 12.dp, horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            val dockApps = prefs.dock.mapNotNull { p -> apps.find { it.pkg == p } }
            if (dockApps.isEmpty()) {
                Text(
                    "Long-press an app to pin it here",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 14.sp,
                    modifier = Modifier.padding(16.dp),
                )
            }
            dockApps.forEach { app ->
                AppItem(app, prefs.iconSize, false, { act.launch(app.pkg) }, actionsFor(app, -1))
            }
        }
    }
}

@Composable
fun Drawer(
    apps: List<AppInfo>,
    prefs: LauncherPrefs,
    query: String,
    onQuery: (String) -> Unit,
    onLaunch: (String) -> Unit,
    actionsFor: (AppInfo, Int?) -> List<MenuItem>,
    onClose: () -> Unit,
) {
    val filtered = remember(apps, query) {
        if (query.isBlank()) apps else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
    }

    Column(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) { detectTapGestures { } }
            .background(Color(0xE6101014))
            .systemBarsPadding()
            .imePadding()
            .padding(horizontal = 12.dp),
    ) {
        Box(
            Modifier
                .padding(top = 10.dp, bottom = 8.dp)
                .align(Alignment.CenterHorizontally)
                .size(width = 40.dp, height = 4.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(Color.White.copy(alpha = 0.3f))
                .pointerInput(Unit) {
                    detectVerticalDragGestures { _, dy -> if (dy > 8f) onClose() }
                }
        )

        TextField(
            value = query,
            onValueChange = onQuery,
            placeholder = { Text("Search apps") },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            colors = TextFieldDefaults.colors(
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                focusedContainerColor = Color.White.copy(alpha = 0.12f),
                unfocusedContainerColor = Color.White.copy(alpha = 0.12f),
            ),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = {
                filtered.firstOrNull()?.let { onLaunch(it.pkg) }
            }),
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 24.dp),
        ) {
            items(filtered, key = { it.pkg }) { app ->
                AppItem(
                    app, prefs.iconSize, prefs.labels,
                    { onLaunch(app.pkg) }, actionsFor(app, null),
                    Modifier.fillMaxWidth(),
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppItem(
    app: AppInfo,
    iconSize: Int,
    showLabel: Boolean,
    onLaunch: () -> Unit,
    menu: List<MenuItem>,
    modifier: Modifier = Modifier,
) {
    var open by remember { mutableStateOf(false) }
    Box(modifier, contentAlignment = Alignment.Center) {
        Column(
            Modifier
                .clip(RoundedCornerShape(16.dp))
                .combinedClickable(onClick = onLaunch, onLongClick = { open = true })
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Image(app.icon, contentDescription = app.label, modifier = Modifier.size(iconSize.dp))
            if (showLabel) {
                Spacer(Modifier.height(4.dp))
                Text(
                    app.label,
                    color = Color.White,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.widthIn(max = (iconSize + 16).dp),
                )
            }
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            menu.forEach { m ->
                DropdownMenuItem(text = { Text(m.label) }, onClick = { open = false; m.run() })
            }
        }
    }
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun SettingsDialog(prefs: LauncherPrefs, onAccessibility: () -> Unit, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(28.dp), color = Color(0xF2181820)) {
            Column(
                Modifier.padding(20.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text("Launcher settings", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Medium)

                Text("Accent colour", color = Color.White.copy(alpha = 0.7f))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    AccentColors.forEachIndexed { i, c ->
                        Box(
                            Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(c)
                                .then(
                                    if (prefs.accent == i) Modifier.border(3.dp, Color.Black, CircleShape)
                                    else Modifier
                                )
                                .clickable { prefs.accent = i; prefs.save() }
                        )
                    }
                }

                Text("Icon size: ${prefs.iconSize}dp", color = Color.White.copy(alpha = 0.7f))
                Slider(
                    value = prefs.iconSize.toFloat(),
                    onValueChange = { prefs.iconSize = it.roundToInt() },
                    onValueChangeFinished = { prefs.save() },
                    valueRange = 40f..76f,
                )

                SwitchRow("Show app names", prefs.labels) { prefs.labels = it; prefs.save() }
                SwitchRow("24-hour clock", prefs.h24) { prefs.h24 = it; prefs.save() }
                SwitchRow("Temperature in °F", prefs.fahrenheit) { prefs.fahrenheit = it; prefs.save() }

                Button(onClick = onAccessibility) { Text("Enable double-tap lock and swipe-down") }
                Text(
                    "In Accessibility settings, open Installed apps, tap Nice Launcher and turn it on.",
                    color = Color.White.copy(alpha = 0.55f),
                    fontSize = 12.sp,
                )
                TextButton(onClick = onDismiss) { Text("Done") }
            }
        }
    }
}
