package com.example.nicelauncher

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.provider.CalendarContract.Instances
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

data class WeatherData(val temp: String, val desc: String, val hi: String, val lo: String)
data class EventItem(val title: String, val whenText: String)

@Composable
fun GlassCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Color.White.copy(alpha = 0.13f))
            .padding(16.dp),
        content = content,
    )
}

@Composable
fun WidgetsPage(prefs: LauncherPrefs, accent: Color) {
    val now by produceState(LocalDateTime.now()) {
        while (true) { value = LocalDateTime.now(); delay(10_000) }
    }
    val time = now.format(DateTimeFormatter.ofPattern(if (prefs.h24) "HH:mm" else "h:mm"))
    val date = now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault()))

    Column(
        Modifier.fillMaxSize().padding(horizontal = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Spacer(Modifier.height(40.dp))
        Text(time, color = accent, fontSize = 72.sp, fontWeight = FontWeight.Light)
        Text(date, color = Color.White.copy(alpha = 0.85f), fontSize = 18.sp)
        Spacer(Modifier.height(8.dp))
        WeatherCard(prefs.fahrenheit, accent)
        CalendarCard(accent)
    }
}

@Composable
fun WeatherCard(fahrenheit: Boolean, accent: Color) {
    val ctx = LocalContext.current
    var granted by remember {
        mutableStateOf(
            ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    val weather by produceState<WeatherData?>(null, granted, fahrenheit) {
        value = if (granted) withContext(Dispatchers.IO) { fetchWeather(ctx, fahrenheit) } else null
    }

    GlassCard {
        Text("WEATHER", color = accent, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        if (!granted) {
            Text(
                "Tap to allow location for local weather",
                color = Color.White,
                modifier = Modifier.clickable {
                    launcher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                },
            )
        } else if (weather == null) {
            Text("Loading weather…", color = Color.White.copy(alpha = 0.7f))
        } else {
            val w = weather!!
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(w.temp, color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.Light)
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(w.desc, color = Color.White, fontSize = 16.sp)
                    if (w.hi.isNotEmpty()) {
                        Text("${w.hi}  ${w.lo}", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun CalendarCard(accent: Color) {
    val ctx = LocalContext.current
    var granted by remember {
        mutableStateOf(
            ctx.checkSelfPermission(Manifest.permission.READ_CALENDAR) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    val events by produceState(emptyList<EventItem>(), granted) {
        value = if (granted) withContext(Dispatchers.IO) { loadEvents(ctx) } else emptyList()
    }

    GlassCard {
        Text("UPCOMING", color = accent, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        if (!granted) {
            Text(
                "Tap to show your calendar events",
                color = Color.White,
                modifier = Modifier.clickable { launcher.launch(Manifest.permission.READ_CALENDAR) },
            )
        } else if (events.isEmpty()) {
            Text("Nothing in the next 3 days", color = Color.White.copy(alpha = 0.7f))
        } else {
            events.forEach { e ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                    Text(e.whenText, color = Color.White.copy(alpha = 0.65f), fontSize = 14.sp, modifier = Modifier.width(92.dp))
                    Text(e.title, color = Color.White, fontSize = 14.sp, maxLines = 1)
                }
            }
        }
    }
}

fun describeWeather(code: Int): String = when (code) {
    0 -> "☀️ Clear"
    1, 2 -> "🌤️ Mostly clear"
    3 -> "☁️ Cloudy"
    45, 48 -> "🌫️ Fog"
    in 51..57 -> "🌦️ Drizzle"
    in 61..67 -> "🌧️ Rain"
    in 71..77 -> "❄️ Snow"
    in 80..82 -> "🌧️ Showers"
    in 95..99 -> "⛈️ Thunderstorm"
    else -> "🌡️ Weather"
}

@SuppressLint("MissingPermission")
fun fetchWeather(ctx: Context, fahrenheit: Boolean): WeatherData {
    return try {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val loc = listOf(
            LocationManager.NETWORK_PROVIDER,
            LocationManager.PASSIVE_PROVIDER,
            LocationManager.GPS_PROVIDER,
        ).mapNotNull {
            try { lm.getLastKnownLocation(it) } catch (e: Exception) { null }
        }.maxByOrNull { it.time }
            ?: return WeatherData("--", "No location yet. Open Maps once, then retry", "", "")

        val unit = if (fahrenheit) "fahrenheit" else "celsius"
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}" +
            "&longitude=${loc.longitude}&current=temperature_2m,weather_code" +
            "&daily=temperature_2m_max,temperature_2m_min&temperature_unit=$unit" +
            "&timezone=auto&forecast_days=1"
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 8000
        conn.readTimeout = 8000
        val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
        val cur = json.getJSONObject("current")
        val daily = json.getJSONObject("daily")
        val t = cur.getDouble("temperature_2m").roundToInt()
        val hi = daily.getJSONArray("temperature_2m_max").getDouble(0).roundToInt()
        val lo = daily.getJSONArray("temperature_2m_min").getDouble(0).roundToInt()
        WeatherData("$t°", describeWeather(cur.getInt("weather_code")), "H:$hi°", "L:$lo°")
    } catch (e: Exception) {
        WeatherData("--", "Weather unavailable", "", "")
    }
}

fun loadEvents(ctx: Context): List<EventItem> {
    val now = System.currentTimeMillis()
    val b = Instances.CONTENT_URI.buildUpon()
    ContentUris.appendId(b, now)
    ContentUris.appendId(b, now + 3L * 24 * 3600 * 1000)
    val out = mutableListOf<EventItem>()
    try {
        ctx.contentResolver.query(
            b.build(),
            arrayOf(Instances.TITLE, Instances.BEGIN, Instances.ALL_DAY),
            null, null, "${Instances.BEGIN} ASC",
        )?.use { c ->
            val fmt = SimpleDateFormat("EEE HH:mm", Locale.getDefault())
            while (c.moveToNext() && out.size < 4) {
                val allDay = c.getInt(2) == 1
                out += EventItem(
                    c.getString(0) ?: "(No title)",
                    if (allDay) "All day" else fmt.format(Date(c.getLong(1))),
                )
            }
        }
    } catch (e: Exception) {
    }
    return out
}
